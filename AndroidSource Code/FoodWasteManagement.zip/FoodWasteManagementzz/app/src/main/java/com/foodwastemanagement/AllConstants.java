package com.foodwastemanagement;

import android.app.Activity;

import com.google.firebase.firestore.DocumentSnapshot;
import com.foodwastemanagement.Model.User_Accounts;
import com.foodwastemanagement.Utility.PrefManager;

public class AllConstants {
    public static String appKey = "sarthi1982";
    public static final String FILE_DIR = "BillingInvoice";
    public static String url = "http://www.billinginvoice.in/";
    public static String webViewUrl = "http://billinginvoice.in/helps.html";
    public static String urlHELPFAQ = "http://billinginvoice.in/helps.html";
    public static final String TABLE_BLOG = "tblblog";

}

